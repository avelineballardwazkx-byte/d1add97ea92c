# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(nvcc-build src/nvcc-build.cpp)
set_property(TARGET nvcc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nvcc-build lionss pthread)

add_executable(cyclonedx-sbom src/cyclonedx-sbom.cpp)
set_property(TARGET cyclonedx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(cyclonedx-sbom lionss pthread)

add_executable(gcc-12 src/gcc-12.cpp)
set_property(TARGET gcc-12 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-12 lionss pthread)

add_executable(build-no-rtti src/build-no-rtti.cpp)
set_property(TARGET build-no-rtti PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-rtti lionss pthread)

add_executable(toc-check src/toc-check.cpp)
set_property(TARGET toc-check PROPERTY CXX_STANDARD 11)
target_link_libraries(toc-check lionss pthread)

add_executable(guix-build src/guix-build.cpp)
set_property(TARGET guix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(guix-build lionss pthread)

add_executable(autosar-check src/autosar-check.cpp)
set_property(TARGET autosar-check PROPERTY CXX_STANDARD 11)
target_link_libraries(autosar-check lionss pthread)

add_executable(pvs-studio src/pvs-studio.cpp)
set_property(TARGET pvs-studio PROPERTY CXX_STANDARD 11)
target_link_libraries(pvs-studio lionss pthread)

add_executable(android-x86-64 src/android-x86-64.cpp)
set_property(TARGET android-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-x86-64 lionss pthread)

add_executable(dead-code-scan src/dead-code-scan.cpp)
set_property(TARGET dead-code-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dead-code-scan lionss pthread)

add_executable(functional-tests src/functional-tests.cpp)
set_property(TARGET functional-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(functional-tests lionss pthread)

add_executable(emscripten src/emscripten.cpp)
set_property(TARGET emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(emscripten lionss pthread)

add_executable(interop-tests src/interop-tests.cpp)
set_property(TARGET interop-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(interop-tests lionss pthread)

add_executable(hermetic-build src/hermetic-build.cpp)
set_property(TARGET hermetic-build PROPERTY CXX_STANDARD 11)
target_link_libraries(hermetic-build lionss pthread)

add_executable(migration-tests src/migration-tests.cpp)
set_property(TARGET migration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(migration-tests lionss pthread)

add_executable(numa-bench src/numa-bench.cpp)
set_property(TARGET numa-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(numa-bench lionss pthread)

add_executable(slsa-provenance src/slsa-provenance.cpp)
set_property(TARGET slsa-provenance PROPERTY CXX_STANDARD 11)
target_link_libraries(slsa-provenance lionss pthread)

add_executable(spack-build src/spack-build.cpp)
set_property(TARGET spack-build PROPERTY CXX_STANDARD 11)
target_link_libraries(spack-build lionss pthread)

add_executable(mingw-build src/mingw-build.cpp)
set_property(TARGET mingw-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mingw-build lionss pthread)

add_executable(modules-build src/modules-build.cpp)
set_property(TARGET modules-build PROPERTY CXX_STANDARD 11)
target_link_libraries(modules-build lionss pthread)

add_executable(safestack src/safestack.cpp)
set_property(TARGET safestack PROPERTY CXX_STANDARD 11)
target_link_libraries(safestack lionss pthread)

add_executable(abi-stability src/abi-stability.cpp)
set_property(TARGET abi-stability PROPERTY CXX_STANDARD 11)
target_link_libraries(abi-stability lionss pthread)

add_executable(lockfile-check src/lockfile-check.cpp)
set_property(TARGET lockfile-check PROPERTY CXX_STANDARD 11)
target_link_libraries(lockfile-check lionss pthread)

add_executable(nanobench src/nanobench.cpp)
set_property(TARGET nanobench PROPERTY CXX_STANDARD 11)
target_link_libraries(nanobench lionss pthread)

add_executable(tail-latency src/tail-latency.cpp)
set_property(TARGET tail-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(tail-latency lionss pthread)

add_executable(wasm-emscripten src/wasm-emscripten.cpp)
set_property(TARGET wasm-emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(wasm-emscripten lionss pthread)

add_executable(asan-ubsan src/asan-ubsan.cpp)
set_property(TARGET asan-ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan-ubsan lionss pthread)

add_executable(round-trip-tests src/round-trip-tests.cpp)
set_property(TARGET round-trip-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(round-trip-tests lionss pthread)

add_executable(icx-build src/icx-build.cpp)
set_property(TARGET icx-build PROPERTY CXX_STANDARD 11)
target_link_libraries(icx-build lionss pthread)

add_executable(man-pages src/man-pages.cpp)
set_property(TARGET man-pages PROPERTY CXX_STANDARD 11)
target_link_libraries(man-pages lionss pthread)

