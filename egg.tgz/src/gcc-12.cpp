// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("gcc 12"); }
int main(){
  announce();
  return lionss_run_workload("gcc-12");
}
