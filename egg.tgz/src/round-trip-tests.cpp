// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("round trip tests\n", stdout);
  return lionss_run_workload("round-trip-tests");
}
