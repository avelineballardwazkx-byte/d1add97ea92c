// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("autosar check\n", stdout);
  return lionss_run_workload("autosar-check");
}
